#ifndef __OLED_H
#define __OLED_H

#include "main.h"

/* =========================================================
 * OLED connection
 *
 * SCK -> PB12
 * SDA -> PB13
 * RES -> PB14
 * DC  -> PB15
 * CS  -> PA8
 * =========================================================
 */

/* SCK */
#define OLED_SCK_H() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET)
#define OLED_SCK_L() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET)

/* SDA */
#define OLED_SDA_H() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET)
#define OLED_SDA_L() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET)

/* RES */
#define OLED_RES_H() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET)
#define OLED_RES_L() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET)

/* DC */
#define OLED_DC_H() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET)
#define OLED_DC_L() HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET)

/* CS */
#define OLED_CS_H() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET)
#define OLED_CS_L() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET)


/* =========================================================
 * Basic OLED functions
 * =========================================================
 */

void OLED_Init(void);

void OLED_WriteCommand(uint8_t Command);

void OLED_WriteData(uint8_t Data);

void OLED_SetCursor(uint8_t Page, uint8_t X);

void OLED_Clear(void);

void OLED_Fill(void);


/* =========================================================
 * Text functions
 * =========================================================
 */

void OLED_ShowChar(uint8_t Page, uint8_t X, char Char);

void OLED_ShowString(uint8_t Page, uint8_t X, char *String);


/* =========================================================
 * Graphic functions
 * =========================================================
 */

/* Clear graphic buffer */
void OLED_ClearBuffer(void);

/* Send graphic buffer to OLED */
void OLED_Update(void);

/* Draw one pixel
 *
 * X: 0 ~ 127
 * Y: 0 ~ 63
 */
void OLED_DrawPoint(uint8_t X, uint8_t Y);

/* Erase one pixel */
void OLED_ClearPoint(uint8_t X, uint8_t Y);

/* Draw line */
void OLED_DrawLine(
    int16_t X0,
    int16_t Y0,
    int16_t X1,
    int16_t Y1
);

/* Draw rectangle */
void OLED_DrawRectangle(
    uint8_t X,
    uint8_t Y,
    uint8_t Width,
    uint8_t Height
);


#endif