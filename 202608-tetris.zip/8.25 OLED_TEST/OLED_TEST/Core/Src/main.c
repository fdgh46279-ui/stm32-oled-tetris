/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Tetris - Two Buttons + Rotation
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* USER CODE BEGIN Includes */
#include "oled.h"
/* USER CODE END Includes */


/* USER CODE BEGIN PTD */

	typedef enum
	{
    PIECE_O = 0,
    PIECE_I,
    PIECE_T,
    PIECE_S
	} PieceType;

	typedef enum
	{
    STATE_START = 0,
    STATE_PLAYING,
    STATE_GAMEOVER
	} GameState;

/* USER CODE END PTD */


/* USER CODE BEGIN PD */

#define MAP_WIDTH       10
#define MAP_HEIGHT      20

#define CELL_SIZE       3

#define FIELD_X         4
#define FIELD_Y         2

#define FALL_INTERVAL   300

/* USER CODE END PD */


/* USER CODE BEGIN PV */

	static uint8_t GameMap[MAP_HEIGHT][MAP_WIDTH];

	static int8_t BlockX = 3;
	static int8_t BlockY = 0;

	static PieceType CurrentPiece = PIECE_O;

	static uint8_t Rotation = 0;

	static GameState CurrentState = STATE_START;

	static uint32_t LastFallTime = 0;

	static uint16_t Score = 0;

/* USER CODE END PV */


/* Function prototypes -------------------------------------------------------*/

	void SystemClock_Config(void);
	static void MX_GPIO_Init(void);


/* USER CODE BEGIN PFP */

	static void ClearMap(void);
	static void Game_Init(void);
	static void StartGame(void);

	static uint8_t GetPieceCell(
    PieceType Type,
    uint8_t RotationValue,
    uint8_t Row,
    uint8_t Column
);

	static void DrawCell(uint8_t GridX, uint8_t GridY);
	static void DrawCurrentPiece(void);
	static void DrawScore(void);
	static void DrawGame(void);

	static void ShowStartScreen(void);
	static void ShowGameOverScreen(void);

	static uint8_t CanPieceMoveTo(
    int8_t NewX,
    int8_t NewY,
    uint8_t NewRotation
);

	static void TryRotate(void);
	static void LockPiece(void);
	static void ClearLines(void);
	static void SpawnNextPiece(void);
	static void KeyScan(void);

/* USER CODE END PFP */


/* USER CODE BEGIN 0 */


/* =========================================================
 * Clear Map
 * =========================================================
 */
	static void ClearMap(void)
	{
    uint8_t x;
    uint8_t y;

    for (y = 0; y < MAP_HEIGHT; y++)
    {
        for (x = 0; x < MAP_WIDTH; x++)
        {
            GameMap[y][x] = 0;
        }
    }
	}


/* =========================================================
 * Game Init
 * =========================================================
 */
	static void Game_Init(void)
	{
    ClearMap();

    CurrentPiece = PIECE_O;

    Rotation = 0;

    BlockX = 3;
    BlockY = 0;

    Score = 0;
	}


/* =========================================================
 * Start Game
 * =========================================================
 */
	static void StartGame(void)
	{
    Game_Init();

    CurrentState = STATE_PLAYING;

    LastFallTime = HAL_GetTick();

    DrawGame();
	}


/* =========================================================
 * Get Piece Cell
 *
 * 4 x 4 coordinate system
 * =========================================================
 */
	static uint8_t GetPieceCell(
    PieceType Type,
    uint8_t RotationValue,
    uint8_t Row,
    uint8_t Column
)
	{
    RotationValue %= 4;


    /* =====================================================
     * O PIECE
     *
     * ##
     * ##
     *
     * Rotation does not change appearance.
     * =====================================================
     */
    if (Type == PIECE_O)
    {
        if (
            (Row == 0 && Column == 0) ||
            (Row == 0 && Column == 1) ||
            (Row == 1 && Column == 0) ||
            (Row == 1 && Column == 1)
        )
        {
            return 1;
        }

        return 0;
    }


    /* =====================================================
     * I PIECE
     * =====================================================
     */
    if (Type == PIECE_I)
    {
        if ((RotationValue % 2) == 0)
        {
            /* #### */

            if (Row == 1 && Column <= 3)
            {
                return 1;
            }
        }
        else
        {
            /*
             * #
             * #
             * #
             * #
             */

            if (Column == 1 && Row <= 3)
            {
                return 1;
            }
        }

        return 0;
    }


    /* =====================================================
     * T PIECE
     * =====================================================
     */
    if (Type == PIECE_T)
    {
        if (RotationValue == 0)
        {
            /*
             *  #
             * ###
             */

            if (
                (Row == 0 && Column == 1) ||
                (Row == 1 && Column <= 2)
            )
            {
                return 1;
            }
        }

        else if (RotationValue == 1)
        {
            /*
             * #
             * ##
             * #
             */

            if (
                (Row == 0 && Column == 1) ||
                (Row == 1 && Column == 1) ||
                (Row == 1 && Column == 2) ||
                (Row == 2 && Column == 1)
            )
            {
                return 1;
            }
        }

        else if (RotationValue == 2)
        {
            /*
             * ###
             *  #
             */

            if (
                (Row == 1 && Column <= 2) ||
                (Row == 2 && Column == 1)
            )
            {
                return 1;
            }
        }

        else
        {
            /*
             *  #
             * ##
             *  #
             */

            if (
                (Row == 0 && Column == 1) ||
                (Row == 1 && Column == 0) ||
                (Row == 1 && Column == 1) ||
                (Row == 2 && Column == 1)
            )
            {
                return 1;
            }
        }

        return 0;
    }


    /* =====================================================
     * S PIECE
     * =====================================================
     */
    if (Type == PIECE_S)
    {
        if ((RotationValue % 2) == 0)
        {
            /*
             *  ##
             * ##
             */

            if (
                (Row == 0 && Column == 1) ||
                (Row == 0 && Column == 2) ||
                (Row == 1 && Column == 0) ||
                (Row == 1 && Column == 1)
            )
            {
                return 1;
            }
        }
        else
        {
            /*
             * #
             * ##
             *  #
             */

            if (
                (Row == 0 && Column == 0) ||
                (Row == 1 && Column == 0) ||
                (Row == 1 && Column == 1) ||
                (Row == 2 && Column == 1)
            )
            {
                return 1;
            }
        }

        return 0;
    }


    return 0;
	}


/* =========================================================
 * Draw Cell
 * =========================================================
 */
static void DrawCell(
    uint8_t GridX,
    uint8_t GridY
)
{
    uint8_t PixelX;
    uint8_t PixelY;

    uint8_t i;
    uint8_t j;

    PixelX = FIELD_X + GridX * CELL_SIZE;

    PixelY = FIELD_Y + GridY * CELL_SIZE;

    for (j = 0; j < CELL_SIZE; j++)
    {
        for (i = 0; i < CELL_SIZE; i++)
        {
            OLED_DrawPoint(
                PixelX + i,
                PixelY + j
            );
        }
    }
}


/* =========================================================
 * Draw Current Piece
 * =========================================================
 */
static void DrawCurrentPiece(void)
{
    uint8_t Row;
    uint8_t Column;

    int8_t DrawX;
    int8_t DrawY;

    for (Row = 0; Row < 4; Row++)
    {
        for (Column = 0; Column < 4; Column++)
        {
            if (
                GetPieceCell(
                    CurrentPiece,
                    Rotation,
                    Row,
                    Column
                ) != 0
            )
            {
                DrawX =
                    BlockX +
                    (int8_t)Column;

                DrawY =
                    BlockY +
                    (int8_t)Row;

                if (
                    DrawX >= 0 &&
                    DrawX < MAP_WIDTH &&
                    DrawY >= 0 &&
                    DrawY < MAP_HEIGHT
                )
                {
                    DrawCell(
                        (uint8_t)DrawX,
                        (uint8_t)DrawY
                    );
                }
            }
        }
    }
}


/* =========================================================
 * Draw Score
 * =========================================================
 */
static void DrawScore(void)
{
    char ScoreString[5];

    uint16_t Value;

    Value = Score;

    if (Value > 9999)
    {
        Value = 9999;
    }

    ScoreString[0] =
        (char)(((Value / 1000) % 10) + '0');

    ScoreString[1] =
        (char)(((Value / 100) % 10) + '0');

    ScoreString[2] =
        (char)(((Value / 10) % 10) + '0');

    ScoreString[3] =
        (char)((Value % 10) + '0');

    ScoreString[4] = '\0';


    OLED_ShowString(
        1,
        48,
        "SCORE"
    );

    OLED_ShowString(
        3,
        48,
        ScoreString
    );
}


/* =========================================================
 * Draw Game
 * =========================================================
 */
static void DrawGame(void)
{
    uint8_t x;
    uint8_t y;

    OLED_ClearBuffer();


    /* Border */
    OLED_DrawRectangle(
        FIELD_X - 1,
        FIELD_Y - 1,
        MAP_WIDTH * CELL_SIZE + 2,
        MAP_HEIGHT * CELL_SIZE + 2
    );


    /* Fixed blocks */
    for (y = 0; y < MAP_HEIGHT; y++)
    {
        for (x = 0; x < MAP_WIDTH; x++)
        {
            if (GameMap[y][x] != 0)
            {
                DrawCell(x, y);
            }
        }
    }


    /* Falling block */
    DrawCurrentPiece();


    OLED_Update();


    DrawScore();
}


/* =========================================================
 * Start Screen
 * =========================================================
 */
static void ShowStartScreen(void)
{
    OLED_Clear();

    OLED_ShowString(
        2,
        38,
        "TETRIS"
    );

    OLED_ShowString(
        5,
        28,
        "PA0 START"
    );
}


/* =========================================================
 * Game Over Screen
 * =========================================================
 */
static void ShowGameOverScreen(void)
{
    char ScoreString[5];

    uint16_t Value;

    Value = Score;

    if (Value > 9999)
    {
        Value = 9999;
    }

    ScoreString[0] =
        (char)(((Value / 1000) % 10) + '0');

    ScoreString[1] =
        (char)(((Value / 100) % 10) + '0');

    ScoreString[2] =
        (char)(((Value / 10) % 10) + '0');

    ScoreString[3] =
        (char)((Value % 10) + '0');

    ScoreString[4] = '\0';


    OLED_Clear();


    OLED_ShowString(
        1,
        34,
        "GAME OVER"
    );

    OLED_ShowString(
        3,
        28,
        "SCORE"
    );

    OLED_ShowString(
        3,
        64,
        ScoreString
    );

    OLED_ShowString(
        6,
        20,
        "PA0 RESTART"
    );
}


/* =========================================================
 * Collision Detection
 *
 * 1 = valid
 * 0 = collision
 * =========================================================
 */
static uint8_t CanPieceMoveTo(
    int8_t NewX,
    int8_t NewY,
    uint8_t NewRotation
)
{
    uint8_t Row;
    uint8_t Column;

    int8_t CheckX;
    int8_t CheckY;

    for (Row = 0; Row < 4; Row++)
    {
        for (Column = 0; Column < 4; Column++)
        {
            if (
                GetPieceCell(
                    CurrentPiece,
                    NewRotation,
                    Row,
                    Column
                ) != 0
            )
            {
                CheckX =
                    NewX +
                    (int8_t)Column;

                CheckY =
                    NewY +
                    (int8_t)Row;


                /* Left / right wall */
                if (
                    CheckX < 0 ||
                    CheckX >= MAP_WIDTH
                )
                {
                    return 0;
                }


                /* Top / bottom */
                if (
                    CheckY < 0 ||
                    CheckY >= MAP_HEIGHT
                )
                {
                    return 0;
                }


                /* Existing block */
                if (
                    GameMap[CheckY][CheckX]
                    != 0
                )
                {
                    return 0;
                }
            }
        }
    }

    return 1;
}


/* =========================================================
 * Try Rotate
 * =========================================================
 */
static void TryRotate(void)
{
    uint8_t NewRotation;

    /*
     * O piece does not need visible rotation
     */
    if (CurrentPiece == PIECE_O)
    {
        return;
    }


    NewRotation =
        (Rotation + 1) % 4;


    /*
     * Only rotate if new position is valid.
     */
    if (
        CanPieceMoveTo(
            BlockX,
            BlockY,
            NewRotation
        ) != 0
    )
    {
        Rotation = NewRotation;

        DrawGame();
    }
}


/* =========================================================
 * Lock Piece
 * =========================================================
 */
static void LockPiece(void)
{
    uint8_t Row;
    uint8_t Column;

    int8_t MapX;
    int8_t MapY;

    for (Row = 0; Row < 4; Row++)
    {
        for (Column = 0; Column < 4; Column++)
        {
            if (
                GetPieceCell(
                    CurrentPiece,
                    Rotation,
                    Row,
                    Column
                ) != 0
            )
            {
                MapX =
                    BlockX +
                    (int8_t)Column;

                MapY =
                    BlockY +
                    (int8_t)Row;


                if (
                    MapX >= 0 &&
                    MapX < MAP_WIDTH &&
                    MapY >= 0 &&
                    MapY < MAP_HEIGHT
                )
                {
                    GameMap[MapY][MapX] = 1;
                }
            }
        }
    }


    Score += 10;
}


/* =========================================================
 * Clear Lines
 * =========================================================
 */
static void ClearLines(void)
{
    int8_t y;
    int8_t MoveY;

    uint8_t x;
    uint8_t Full;

    y = MAP_HEIGHT - 1;

    while (y >= 0)
    {
        Full = 1;


        for (x = 0; x < MAP_WIDTH; x++)
        {
            if (GameMap[y][x] == 0)
            {
                Full = 0;
                break;
            }
        }


        if (Full != 0)
        {
            Score += 100;


            for (
                MoveY = y;
                MoveY > 0;
                MoveY--
            )
            {
                for (
                    x = 0;
                    x < MAP_WIDTH;
                    x++
                )
                {
                    GameMap[MoveY][x] =
                        GameMap[MoveY - 1][x];
                }
            }


            for (x = 0; x < MAP_WIDTH; x++)
            {
                GameMap[0][x] = 0;
            }
        }
        else
        {
            y--;
        }
    }
}


/* =========================================================
 * Next Piece
 *
 * O -> I -> T -> S -> O
 * =========================================================
 */
static void SpawnNextPiece(void)
{
    if (CurrentPiece == PIECE_O)
    {
        CurrentPiece = PIECE_I;
    }
    else if (CurrentPiece == PIECE_I)
    {
        CurrentPiece = PIECE_T;
    }
    else if (CurrentPiece == PIECE_T)
    {
        CurrentPiece = PIECE_S;
    }
    else
    {
        CurrentPiece = PIECE_O;
    }


    /*
     * Every new piece starts at rotation 0.
     */
    Rotation = 0;


    BlockX = 3;
    BlockY = 0;


    if (
        CanPieceMoveTo(
            BlockX,
            BlockY,
            Rotation
        ) == 0
    )
    {
        CurrentState =
            STATE_GAMEOVER;

        ShowGameOverScreen();
    }
}


/* =========================================================
 * Key Scan
 *
 * PA0 only       = LEFT
 * PA1 only       = RIGHT
 * PA0 + PA1      = ROTATE
 * =========================================================
 */
static void KeyScan(void)
{
    GPIO_PinState KeyLeft;
    GPIO_PinState KeyRight;


    KeyLeft =
        HAL_GPIO_ReadPin(
            GPIOA,
            GPIO_PIN_0
        );


    KeyRight =
        HAL_GPIO_ReadPin(
            GPIOA,
            GPIO_PIN_1
        );


    /*
     * START / GAME OVER
     *
     * PA0 starts or restarts game.
     */
    if (
        CurrentState == STATE_START ||
        CurrentState == STATE_GAMEOVER
    )
    {
        if (KeyLeft == GPIO_PIN_RESET)
        {
            HAL_Delay(20);


            if (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_0
                ) == GPIO_PIN_RESET
            )
            {
                while (
                    HAL_GPIO_ReadPin(
                        GPIOA,
                        GPIO_PIN_0
                    ) == GPIO_PIN_RESET
                )
                {
                    HAL_Delay(1);
                }


                HAL_Delay(20);


                StartGame();
            }
        }


        return;
    }


    /*
     * =====================================================
     * BOTH BUTTONS
     *
     * Highest priority:
     * ROTATE
     * =====================================================
     */
    if (
        KeyLeft == GPIO_PIN_RESET &&
        KeyRight == GPIO_PIN_RESET
    )
    {
        HAL_Delay(20);


        if (
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_0
            ) == GPIO_PIN_RESET
            &&
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_1
            ) == GPIO_PIN_RESET
        )
        {
            TryRotate();


            /*
             * Wait until BOTH buttons are released.
             *
             * This prevents one press from rotating
             * many times.
             */
            while (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_0
                ) == GPIO_PIN_RESET
                ||
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_1
                ) == GPIO_PIN_RESET
            )
            {
                HAL_Delay(1);
            }


            HAL_Delay(20);


            return;
        }
    }


    /*
     * =====================================================
     * PA0 ONLY
     *
     * LEFT
     * =====================================================
     */
    if (
        KeyLeft == GPIO_PIN_RESET &&
        KeyRight == GPIO_PIN_SET
    )
    {
        /*
         * Small delay gives the second button
         * a chance to be pressed for rotation.
         */
        HAL_Delay(35);


        KeyLeft =
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_0
            );


        KeyRight =
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_1
            );


        /*
         * User pressed second button during delay:
         * rotate instead of moving left.
         */
        if (
            KeyLeft == GPIO_PIN_RESET &&
            KeyRight == GPIO_PIN_RESET
        )
        {
            TryRotate();


            while (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_0
                ) == GPIO_PIN_RESET
                ||
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_1
                ) == GPIO_PIN_RESET
            )
            {
                HAL_Delay(1);
            }


            HAL_Delay(20);


            return;
        }


        if (
            KeyLeft == GPIO_PIN_RESET &&
            KeyRight == GPIO_PIN_SET
        )
        {
            if (
                CanPieceMoveTo(
                    BlockX - 1,
                    BlockY,
                    Rotation
                ) != 0
            )
            {
                BlockX--;

                DrawGame();
            }


            while (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_0
                ) == GPIO_PIN_RESET
            )
            {
                HAL_Delay(1);
            }


            HAL_Delay(20);
        }


        return;
    }


    /*
     * =====================================================
     * PA1 ONLY
     *
     * RIGHT
     * =====================================================
     */
    if (
        KeyRight == GPIO_PIN_RESET &&
        KeyLeft == GPIO_PIN_SET
    )
    {
        /*
         * Wait briefly for possible PA0 press.
         */
        HAL_Delay(35);


        KeyLeft =
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_0
            );


        KeyRight =
            HAL_GPIO_ReadPin(
                GPIOA,
                GPIO_PIN_1
            );


        /*
         * Both now pressed:
         * rotate instead of moving right.
         */
        if (
            KeyLeft == GPIO_PIN_RESET &&
            KeyRight == GPIO_PIN_RESET
        )
        {
            TryRotate();


            while (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_0
                ) == GPIO_PIN_RESET
                ||
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_1
                ) == GPIO_PIN_RESET
            )
            {
                HAL_Delay(1);
            }


            HAL_Delay(20);


            return;
        }


        if (
            KeyRight == GPIO_PIN_RESET &&
            KeyLeft == GPIO_PIN_SET
        )
        {
            if (
                CanPieceMoveTo(
                    BlockX + 1,
                    BlockY,
                    Rotation
                ) != 0
            )
            {
                BlockX++;

                DrawGame();
            }


            while (
                HAL_GPIO_ReadPin(
                    GPIOA,
                    GPIO_PIN_1
                ) == GPIO_PIN_RESET
            )
            {
                HAL_Delay(1);
            }


            HAL_Delay(20);
        }


        return;
    }
}

/* USER CODE END 0 */


/**
  * @brief Application Entry Point
  */
int main(void)
{
    HAL_Init();


    SystemClock_Config();


    MX_GPIO_Init();


    /* USER CODE BEGIN 2 */


    HAL_Delay(500);


    OLED_Init();


    CurrentState =
        STATE_START;


    ShowStartScreen();


    /* USER CODE END 2 */


    while (1)
    {
        /*
         * Read buttons
         */
        KeyScan();


        /*
         * Automatic falling only during game
         */
        if (
            CurrentState ==
            STATE_PLAYING
        )
        {
            if (
                (HAL_GetTick() - LastFallTime)
                >= FALL_INTERVAL
            )
            {
                LastFallTime =
                    HAL_GetTick();


                /*
                 * Can move down
                 */
                if (
                    CanPieceMoveTo(
                        BlockX,
                        BlockY + 1,
                        Rotation
                    ) != 0
                )
                {
                    BlockY++;

                    DrawGame();
                }
                else
                {
                    /*
                     * Piece landed
                     */
                    LockPiece();


                    /*
                     * Check full lines
                     */
                    ClearLines();


                    /*
                     * Generate next piece
                     */
                    SpawnNextPiece();


                    /*
                     * Refresh only if still playing
                     */
                    if (
                        CurrentState ==
                        STATE_PLAYING
                    )
                    {
                        DrawGame();

                        LastFallTime =
                            HAL_GetTick();
                    }
                }
            }
        }
    }
}


/**
  * @brief System Clock Configuration
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};

    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


    RCC_OscInitStruct.OscillatorType =
        RCC_OSCILLATORTYPE_HSI;


    RCC_OscInitStruct.HSIState =
        RCC_HSI_ON;


    RCC_OscInitStruct.HSICalibrationValue =
        RCC_HSICALIBRATION_DEFAULT;


    RCC_OscInitStruct.PLL.PLLState =
        RCC_PLL_NONE;


    if (
        HAL_RCC_OscConfig(
            &RCC_OscInitStruct
        ) != HAL_OK
    )
    {
        Error_Handler();
    }


    RCC_ClkInitStruct.ClockType =
        RCC_CLOCKTYPE_HCLK |
        RCC_CLOCKTYPE_SYSCLK |
        RCC_CLOCKTYPE_PCLK1 |
        RCC_CLOCKTYPE_PCLK2;


    RCC_ClkInitStruct.SYSCLKSource =
        RCC_SYSCLKSOURCE_HSI;


    RCC_ClkInitStruct.AHBCLKDivider =
        RCC_SYSCLK_DIV1;


    RCC_ClkInitStruct.APB1CLKDivider =
        RCC_HCLK_DIV1;


    RCC_ClkInitStruct.APB2CLKDivider =
        RCC_HCLK_DIV1;


    if (
        HAL_RCC_ClockConfig(
            &RCC_ClkInitStruct,
            FLASH_LATENCY_0
        ) != HAL_OK
    )
    {
        Error_Handler();
    }
}


/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};


    __HAL_RCC_GPIOD_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();


    /*
     * OLED initial output levels
     */
    HAL_GPIO_WritePin(
        GPIOB,
        OLED_SCK_Pin |
        OLED_SDA_Pin |
        OLED_RES_Pin |
        OLED_DC_Pin,
        GPIO_PIN_RESET
    );


    HAL_GPIO_WritePin(
        OLED_CS_GPIO_Port,
        OLED_CS_Pin,
        GPIO_PIN_RESET
    );


    /*
     * OLED GPIO
     */
    GPIO_InitStruct.Pin =
        OLED_SCK_Pin |
        OLED_SDA_Pin |
        OLED_RES_Pin |
        OLED_DC_Pin;


    GPIO_InitStruct.Mode =
        GPIO_MODE_OUTPUT_PP;


    GPIO_InitStruct.Pull =
        GPIO_NOPULL;


    GPIO_InitStruct.Speed =
        GPIO_SPEED_FREQ_LOW;


    HAL_GPIO_Init(
        GPIOB,
        &GPIO_InitStruct
    );


    /*
     * OLED CS
     */
    GPIO_InitStruct.Pin =
        OLED_CS_Pin;


    GPIO_InitStruct.Mode =
        GPIO_MODE_OUTPUT_PP;


    GPIO_InitStruct.Pull =
        GPIO_NOPULL;


    GPIO_InitStruct.Speed =
        GPIO_SPEED_FREQ_LOW;


    HAL_GPIO_Init(
        OLED_CS_GPIO_Port,
        &GPIO_InitStruct
    );


    /*
     * PA0 = LEFT
     */
    GPIO_InitStruct.Pin =
        GPIO_PIN_0;


    GPIO_InitStruct.Mode =
        GPIO_MODE_INPUT;


    GPIO_InitStruct.Pull =
        GPIO_PULLUP;


    HAL_GPIO_Init(
        GPIOA,
        &GPIO_InitStruct
    );


    /*
     * PA1 = RIGHT
     */
    GPIO_InitStruct.Pin =
        GPIO_PIN_1;


    GPIO_InitStruct.Mode =
        GPIO_MODE_INPUT;


    GPIO_InitStruct.Pull =
        GPIO_PULLUP;


    HAL_GPIO_Init(
        GPIOA,
        &GPIO_InitStruct
    );
}


/**
  * @brief Error Handler
  */
void Error_Handler(void)
{
    __disable_irq();

    while (1)
    {
    }
}


#ifdef USE_FULL_ASSERT

void assert_failed(
    uint8_t *file,
    uint32_t line
)
{
}

#endif